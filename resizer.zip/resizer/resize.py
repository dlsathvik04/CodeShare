from PIL import Image
import io
import os
import cv2
import numpy as np

output_dir = "./output_resize"
input_dir = './input_resize'
photo_suffix = '.jpg'
size_threshold = 15  # Target size in KB

def resize_image_to_target_kb(image_path, target_kb):
    """Resizes an image to approximately the target size in KB."""
    img = Image.open(image_path)
    img = img.convert('RGB')
    
    # Initially save the image to a temporary file to check its size
    temp_path = "./temp_image.jpg"
    img.save(temp_path)

    # Check the initial file size
    file_size_kb = os.path.getsize(temp_path) / 1024 

    while file_size_kb > target_kb-1:
        # Resize the image by 98% each time
        new_width = int(img.width * 0.98)
        new_height = int(img.height * 0.98)
        img = img.resize((new_width, new_height))

        # Save to temp file and check size
        img.save(temp_path)
        file_size_kb = os.path.getsize(temp_path) / 1024  # Get file size in KB
    print(f"{image_path} File size after resizing: {file_size_kb:.2f} KB")

    # Remove the temporary file after processing
    os.remove(temp_path)
    return img

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

for photo in os.listdir(input_dir):
    if photo.endswith(photo_suffix):  # Only process .jpg files
        # Resize the image to target size
        res = resize_image_to_target_kb(os.path.join(input_dir, photo), size_threshold)
        
        # Save the resized image to output directory
        res.save(os.path.join(output_dir, photo))

