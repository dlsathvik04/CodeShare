import os

from PIL import Image
import cv2
import numpy as np

from cropper import detect_and_crop_face_return
from merger import resize_and_stack_images
from signs import crop_handwritten_text_return

output_dir = "./output"
input_dir = './input'
photo_suffix = 'photo.jpg'
size_threshold = 15

def increase_contrast_and_denoise(image: np.ndarray) -> np.ndarray:
    # Step 1: Convert the image to LAB color space
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    
    # Step 2: Split the LAB image into L, A, and B channels
    l, a, b = cv2.split(lab)
    
    # Step 3: Apply histogram equalization to the L channel
    l = cv2.equalizeHist(l)
    
    # Step 4: Merge the channels back together
    lab = cv2.merge((l, a, b))
    
    # Step 5: Convert back to BGR color space
    contrast_image = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    
    # Step 6: Apply Gaussian blur to reduce noise
    # Adjust the kernel size as needed (must be positive and odd)
    denoised_image = cv2.GaussianBlur(contrast_image, (7, 7), 0)
    
    # Alternatively, you can use median blur for stronger noise reduction:
    # denoised_image = cv2.medianBlur(contrast_image, 5)
    
    # Step 7: Further enhance contrast and brightness if needed
    alpha = 2.5  # Contrast control (1.0-3.0)
    beta = 75   # Brightness control (0-100)
    
    final_image = cv2.convertScaleAbs(denoised_image, alpha=alpha, beta=beta)
    
    return final_image


def resize_image_to_target_kb(img, target_kb):
    
    # Initially save the image to a temporary file to check its size
    temp_path = "./temp_image.jpg"
    img.save(temp_path)

    # Check the initial file size
    file_size_kb = os.path.getsize(temp_path) / 1024 

    while file_size_kb > target_kb-1:
        # Resize the image by 98% each time
        new_width = int(img.width * 0.98)
        new_height = int(img.height * 0.98)
        img = img.resize((new_width, new_height))

        # Save to temp file and check size
        img.save(temp_path)
        file_size_kb = os.path.getsize(temp_path) / 1024 

    # Remove the temporary file after processing
    os.remove(temp_path)
    return img


os.makedirs(output_dir, exist_ok=True)
i = 0
for person_dir in os.listdir(input_dir):
    i+=1
    if os.path.isdir(os.path.join(input_dir,person_dir)):
        person_files = os.listdir(os.path.join(input_dir,person_dir))
        if (len(person_files) != 2):
            print("the directory ", person_dir, " is not correctly structured")
            exit(0)
        photo = None
        sign = None
        for f in person_files:
            if f.endswith("photo.jpg"):
                photo = os.path.join(input_dir, person_dir, f)
            else :
                sign = os.path.join(input_dir, person_dir, f)
        if (photo is None) or (sign is None):
            print("the directory ", person_dir, " is not correctly structured")
            exit(0)
        pp = detect_and_crop_face_return(photo)
        
        si = crop_handwritten_text_return(sign)
        res = resize_and_stack_images(pp, si)
        res = cv2.cvtColor(res, cv2.COLOR_BGR2RGB) 
        res = Image.fromarray(res)
        res = resize_image_to_target_kb(res, size_threshold)
        # cv2.imwrite(os.path.join(output_dir, person_dir) + ".jpg", res)
        out_path = os.path.join(output_dir, person_dir) + ".jpg"
        res.save(out_path)
        print("successfully processed ", person_dir)
