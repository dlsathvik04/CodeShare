import os
import sys

from PIL import Image
import cv2
import numpy as np

from cropper import detect_and_crop_face, detect_and_crop_face_return
from merger import resize_and_stack_images
from signs import crop_handwritten_text_return

output_dir = "./output"
input_dir = './input'
photo_suffix = 'photo.jpg'
size_threshold = int(sys.argv[2])


def resize_image_to_target_kb(img : Image, target_kb : int) -> Image:
    temp_path = "./temp_image.jpg"
    img.save(temp_path)
    file_size_kb = os.path.getsize(temp_path) / 1024 

    while file_size_kb > target_kb-1:
        new_width = int(img.width * 0.98)
        new_height = int(img.height * 0.98)
        img = img.resize((new_width, new_height))
        img.save(temp_path)
        file_size_kb = os.path.getsize(temp_path) / 1024 
    os.remove(temp_path)
    return img

MODE = sys.argv[1]

if MODE == 'MERGE':
    os.makedirs(output_dir, exist_ok=True)
    i = 0
    for person_dir in os.listdir(input_dir):
        i+=1
        if os.path.isdir(os.path.join(input_dir,person_dir)):
            person_files = os.listdir(os.path.join(input_dir,person_dir))
            if (len(person_files) != 2):
                print("the directory ", person_dir, " is not correctly structured")
                exit(0)
            photo = None
            sign = None
            for f in person_files:
                if f.endswith("photo.jpg"):
                    photo = os.path.join(input_dir, person_dir, f)
                else :
                    sign = os.path.join(input_dir, person_dir, f)
            if (photo is None) or (sign is None):
                print("the directory ", person_dir, " is not correctly structured")
                exit(0)
            else:
                pp = detect_and_crop_face_return(photo)
                si = crop_handwritten_text_return(sign)
                res = resize_and_stack_images(pp, si)
                res = cv2.cvtColor(res, cv2.COLOR_BGR2RGB) 
                res = Image.fromarray(res)
                res = resize_image_to_target_kb(res, size_threshold)
                out_path = os.path.join(output_dir, person_dir) + "_merged.jpg"
                res.save(out_path)
                print("successfully processed ", person_dir)
elif MODE == 'CROP':
    os.makedirs(output_dir, exist_ok=True)
    for photo in os.listdir(input_dir):
        photo_path = os.path.join(input_dir, photo)
        if os.path.isdir(photo_path):
            continue
        pp = detect_and_crop_face_return(photo_path)
        res = cv2.cvtColor(pp, cv2.COLOR_BGR2RGB) 
        res = Image.fromarray(res)
        res = resize_image_to_target_kb(res, size_threshold)
        out_path = os.path.join(output_dir, photo)
        res.save(out_path)
        print("successfully processed ", photo)

else:
    os.makedirs(output_dir, exist_ok=True)
    for photo in os.listdir(input_dir):
        photo_path = os.path.join(input_dir, photo)
        if os.path.isdir(photo_path):
            continue
        res = Image.open(photo_path)
        res = res.convert('RGB')
        res = resize_image_to_target_kb(res, size_threshold)
        out_path = os.path.join(output_dir, photo)
        res.save(out_path)
        print("successfully processed ", photo)
